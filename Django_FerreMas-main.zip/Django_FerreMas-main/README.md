# Django_FerreMas
# Made by: Ruben Ramirez Ross
# Always use 'python manage.py runserver' To run this Proyect!
# Usuarios y contraseñas para acceder a roles
Usuarios: bodeguero, vendedor | Password: Abcd_123
Usuario: admin | Password: admin
Usuario: cliente | Password: Abcd_1234
Usuario: Juanito | password: abc_123456

