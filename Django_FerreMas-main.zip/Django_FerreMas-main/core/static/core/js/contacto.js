// Importamos las funciones necesarias desde validaciones.js
import { isEmail, messageValidate, get, valid } from "./validaciones.js";

// Función de validación principal al enviar el formulario
const validacion = (e) => {
    e.preventDefault(); // Prevenir el envío automático del formulario

    let count = 0;

    // Validación del campo de correo electrónico
    if (!valid(isEmail(get("inputEmailCont").value), "inputEmailCont", "errorEmailCont")) {
        get("emailHelpCont").style.display = "none";
    } else {
        count += 1;
    }

    // Validación del campo de mensaje
    if (!valid(messageValidate(get("inputText").value), "inputText", "errorMensajeCont")) {
        get("mensajeCont").style.display = "none";
    } else {
        count += 1;
    }

    // Si ambos campos son válidos, se puede proceder con el envío del formulario
    if (count === 2) {
        // Aquí puedes agregar lógica adicional, como enviar los datos por AJAX
        window.alert("Mensaje Enviado!"); // Mensaje de alerta, puedes cambiar esto por una acción real
    }
};

// Event listener para la validación al hacer blur en el campo de correo electrónico
get("inputEmailCont").addEventListener("blur", function (event) {
    if (!valid(isEmail(get("inputEmailCont").value), "inputEmailCont", "errorEmailCont")) {
        get("emailHelpCont").style.display = "none";
    }
});

// Event listener para la validación al hacer blur en el campo de mensaje
get("inputText").addEventListener("blur", function (event) {
    if (!valid(messageValidate(get("inputText").value), "inputText", "errorMensajeCont")) {
        get("mensajeCont").style.display = "none";
    }
});

// Event listener para activar la función de validación al hacer click en el botón Enviar
get("botonEnviar").addEventListener('click', validacion);
